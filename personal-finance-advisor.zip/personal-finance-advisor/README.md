# 💰 Personal Finance Advisor Bot

An AI-powered personal finance management web app built with Flask. Track income and
expenses, plan category budgets, set savings goals, and get AI-generated (or
rule-based fallback) financial recommendations — all from one dashboard.

## Features

- Secure registration/login with hashed passwords (Flask-Login + Werkzeug)
- Per-user data isolation — every query is scoped to the logged-in user
- Income tracking with categories, editing, and deletion
- Expense tracking with default + custom categories
- Monthly, category-wise budgeting with over-budget detection
- Savings goals with progress bars
- Interactive Chart.js dashboard (category breakdown, income vs. expenses,
  spending trend, budget vs. actual)
- AI Financial Advisor (Gemini or OpenAI) for spending analysis, savings tips,
  and a financial health summary
- AI Budget Generator that suggests a full monthly budget
- **Works fully without an AI API key** — every AI feature has a local,
  rule-based fallback so the app never crashes or feels broken in a demo
- Monthly printable reports
- Friendly 404/403/500 error pages

## Technology Stack

- **Backend:** Python, Flask, Flask-SQLAlchemy, Flask-Login, Werkzeug
- **Database:** SQLite (default) or PostgreSQL via `DATABASE_URL`
- **Frontend:** Jinja2, Bootstrap 5, vanilla JavaScript, Chart.js
- **AI:** Google Gemini API or OpenAI API (configurable, optional)
- **Deployment:** Gunicorn, Render (`render.yaml`) or any Flask-compatible host; Ngrok for quick demos

## Project Structure

```
personal-finance-advisor/
│
├── app/
│   ├── __init__.py          # App factory, extensions, error handlers
│   ├── models.py            # SQLAlchemy models
│   ├── auth.py               # Register/login/logout routes
│   ├── routes.py             # Dashboard, income, expenses, budget, savings, advisor, reports
│   ├── ai_service.py         # AI calls + local fallback logic
│   ├── finance_service.py    # Pure calculation helpers (income, expenses, savings, budgets)
│   ├── templates/            # Jinja2 templates
│   └── static/
│       ├── css/style.css
│       └── js/dashboard.js
│
├── tests/                     # pytest test suite
├── instance/                  # local SQLite DB lives here (gitignored)
├── config.py                  # Environment-based configuration
├── run.py                     # App entry point
├── seed.py                    # Optional demo data generator
├── requirements.txt
├── Procfile                   # For Render/Heroku-style deployment
├── render.yaml                # Render deployment blueprint
├── .env.example
└── .gitignore
```

## 1. Installation (Windows)

```bat
git clone <your-repo-url>
cd personal-finance-advisor

python -m venv venv
venv\Scripts\activate

pip install -r requirements.txt
```

> macOS/Linux: use `python3 -m venv venv` and `source venv/bin/activate` instead.

## 2. Configure Environment Variables

Copy the example file and edit it:

```bat
copy .env.example .env
```

Open `.env` and set at minimum a `SECRET_KEY`. Leave `GEMINI_API_KEY` /
`OPENAI_API_KEY` blank if you don't want AI features yet — the app will
automatically use local fallback analysis instead.

```
SECRET_KEY=some-long-random-string
DATABASE_URL=sqlite:///finance.db
AI_PROVIDER=gemini
GEMINI_API_KEY=
OPENAI_API_KEY=
```

## 3. Initialize the Database

The database and tables are created automatically the first time the app
starts (see `create_app()` in `app/__init__.py`), so no manual migration step
is required for a fresh SQLite setup.

Optionally load demo data:

```bat
python seed.py
```

This creates a demo account (`demo@example.com` / `demo1234`) with sample
income, expenses, budgets, and a savings goal. It never touches other users'
data.

## 4. Run Locally

```bat
python run.py
```

Visit **http://127.0.0.1:5000** in your browser.

## 5. Configure Gemini API (Optional)

1. Get an API key from [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Put it in `.env` as `GEMINI_API_KEY=your_key_here` and make sure
   `AI_PROVIDER=gemini`.
3. Restart the app. The AI Advisor and AI Budget Generator pages will now use
   live AI responses instead of the fallback analysis.

To use OpenAI instead, set `AI_PROVIDER=openai` and `OPENAI_API_KEY=your_key_here`.

## 6. Using the Application

1. Register an account on `/register`.
2. Log in and update your profile (`/profile`) with your monthly income,
   savings target, and financial goal.
3. Add income (`/income`) and expenses (`/expenses`).
4. Set monthly budgets by category (`/budget`).
5. Create savings goals (`/savings`) and add contributions over time.
6. Check `/dashboard` for charts and an overview.
7. Visit `/advisor` for AI-generated (or fallback) recommendations, and
   `/advisor/budget-generator` for a suggested budget.
8. Use `/reports` to view or print a monthly summary.

## 7. Running Tests

```bat
pytest
```

The test suite covers registration, login/logout, protected routes, income
and expense CRUD, budget and savings goal creation, financial calculations
(including division-by-zero safety), and the AI advisor fallback path.

## 8. Using Ngrok for a Temporary Public Demo

1. [Download Ngrok](https://ngrok.com/download) and sign in (`ngrok config add-authtoken <token>`).
2. Start the Flask app: `python run.py`
3. In another terminal: `ngrok http 5000`
4. Share the generated `https://....ngrok-free.app` URL for a live demo.

Ngrok is only for temporary demos — it is not required for permanent deployment.

## 9. Upload to GitHub

```bat
git init
git add .
git commit -m "Initial commit: Personal Finance Advisor Bot"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

`.env`, the SQLite database, and `instance/` are excluded via `.gitignore` —
never commit real secrets or your local database file.

## 10. Deploy to Render

1. Push the project to GitHub (see above).
2. On [Render](https://render.com), create a new **Web Service** from your repo.
   `render.yaml` is already configured with the build/start commands.
3. Render will run `pip install -r requirements.txt` then `gunicorn run:app`.
4. Add a PostgreSQL database in Render (optional but recommended for
   production) and copy its connection string into the `DATABASE_URL`
   environment variable on the service.
5. Set `SECRET_KEY`, `AI_PROVIDER`, and `GEMINI_API_KEY`/`OPENAI_API_KEY` in
   the Render dashboard's **Environment** tab.
6. Deploy. Render provides a public HTTPS URL automatically.

## 11. Getting the Public URL

- **Render:** shown on your service's dashboard (e.g. `https://your-app.onrender.com`).
- **Ngrok:** printed in the terminal after running `ngrok http 5000`.

## Security Notes

- Passwords are never stored in plain text (Werkzeug's `generate_password_hash`).
- All financial routes are protected with `@login_required` and filter every
  query by the logged-in user's ID, so users cannot see each other's data.
- API keys are read only from environment variables, never hard-coded or sent
  to the frontend.
- Errors are handled gracefully; stack traces are not shown to end users.
- Review `.gitignore` before pushing to make sure `.env` and any local
  database files are excluded.

## Future Improvements

- Multi-currency support with live exchange rates
- Recurring income/expense templates
- Email notifications for budget overruns
- Export reports to PDF/CSV
- Multi-factor authentication
- Support for shared/household budgets

## Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError` | Make sure the virtual environment is activated and `pip install -r requirements.txt` completed successfully. |
| App starts but AI pages show "unavailable" | This is expected without an API key — it's the required fallback behavior, not a bug. Add a key in `.env` to enable live AI. |
| `sqlite3.OperationalError: unable to open database file` | Make sure the `instance/` folder exists and is writable; it's created automatically on first run. |
| Changes to `.env` not taking effect | Restart the Flask process — environment variables are only read at startup. |
| Port 5000 already in use | Set `PORT=5001` (or another free port) before running `python run.py`. |
