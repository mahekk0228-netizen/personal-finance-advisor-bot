"""
AI Financial Advisor service.

All calls to an external AI provider (Gemini or OpenAI) live here, isolated
from the route handlers. Every public function is designed to NEVER raise:
if the API key is missing, the network call fails, or the response is
malformed, we fall back to a rule-based analysis generated locally so the
app keeps working during a demo or offline.
"""
import json
import os

import requests
from flask import current_app

GEMINI_ENDPOINT = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "gemini-1.5-flash:generateContent"
)
OPENAI_ENDPOINT = "https://api.openai.com/v1/chat/completions"

DISCLAIMER = (
    "These suggestions are general informational guidance generated for "
    "educational purposes and are not professional financial advice."
)


def _is_configured():
    provider = current_app.config.get("AI_PROVIDER", "gemini")
    if provider == "gemini":
        return bool(current_app.config.get("GEMINI_API_KEY"))
    if provider == "openai":
        return bool(current_app.config.get("OPENAI_API_KEY"))
    return False


def _call_gemini(prompt):
    api_key = current_app.config.get("GEMINI_API_KEY")
    url = f"{GEMINI_ENDPOINT}?key={api_key}"
    payload = {"contents": [{"parts": [{"text": prompt}]}]}
    response = requests.post(url, json=payload, timeout=15)
    response.raise_for_status()
    data = response.json()
    return data["candidates"][0]["content"]["parts"][0]["text"]


def _call_openai(prompt):
    api_key = current_app.config.get("OPENAI_API_KEY")
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": "You are a helpful personal finance advisor."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.6,
    }
    response = requests.post(OPENAI_ENDPOINT, headers=headers, json=payload, timeout=15)
    response.raise_for_status()
    data = response.json()
    return data["choices"][0]["message"]["content"]


def _call_ai(prompt):
    """Returns (text, error). error is None on success."""
    if not _is_configured():
        return None, "not_configured"

    provider = current_app.config.get("AI_PROVIDER", "gemini")
    try:
        if provider == "openai":
            text = _call_openai(prompt)
        else:
            text = _call_gemini(prompt)
        if not text or not text.strip():
            return None, "empty_response"
        return text.strip(), None
    except requests.exceptions.RequestException:
        return None, "request_failed"
    except (KeyError, IndexError, json.JSONDecodeError):
        return None, "bad_response"
    except Exception:
        return None, "unknown_error"


def _fallback_notice():
    return "AI recommendations are currently unavailable. Basic financial analysis is still available."


def analyze_spending(summary):
    """summary: dict with income, expenses, savings, expenses_by_category, budget_status."""
    prompt = (
        "You are a personal finance advisor. Based on this user's monthly financial summary, "
        "provide a short spending analysis (3-5 sentences) highlighting notable patterns, "
        "categories of concern, and one actionable tip. Be specific but concise.\n\n"
        f"Financial summary (JSON): {json.dumps(summary)}"
    )
    text, error = _call_ai(prompt)
    if error:
        return _fallback_spending_analysis(summary), False
    return text, True


def generate_savings_recommendation(summary):
    prompt = (
        "You are a personal finance advisor. Based on this user's financial summary, give a short "
        "savings recommendation (2-4 sentences) including one concrete action they could take this month.\n\n"
        f"Financial summary (JSON): {json.dumps(summary)}"
    )
    text, error = _call_ai(prompt)
    if error:
        return _fallback_savings_recommendation(summary), False
    return text, True


def generate_financial_summary(summary):
    prompt = (
        "You are a personal finance advisor. Write a short (4-6 sentence) overall financial health "
        "summary for this user, covering income vs expenses, savings rate, and budget discipline. "
        "End with one piece of encouragement or a warning if appropriate.\n\n"
        f"Financial summary (JSON): {json.dumps(summary)}"
    )
    text, error = _call_ai(prompt)
    if error:
        return _fallback_financial_summary(summary), False
    return text, True


def generate_budget(income, savings_target, financial_goal, existing_expenses=None):
    """Generate a suggested category-wise monthly budget.

    Returns (budget_dict, used_ai: bool). budget_dict maps category -> amount.
    """
    prompt = (
        "You are a personal finance advisor. Suggest a monthly budget breakdown for a user with the "
        "following details. Respond ONLY with a JSON object mapping these exact category names to "
        "numeric amounts: Housing, Food, Transport, Utilities, Shopping, Entertainment, Healthcare, "
        "Savings, Other. The amounts must sum to approximately the monthly income.\n\n"
        f"Monthly income: {income}\n"
        f"Savings target: {savings_target}\n"
        f"Financial goal: {financial_goal}\n"
        f"Existing expenses (JSON, may be empty): {json.dumps(existing_expenses or {})}"
    )
    text, error = _call_ai(prompt)
    if not error:
        try:
            cleaned = text.strip().strip("`")
            if cleaned.lower().startswith("json"):
                cleaned = cleaned[4:].strip()
            budget = json.loads(cleaned)
            budget = {k: float(v) for k, v in budget.items()}
            return budget, True
        except (ValueError, json.JSONDecodeError, AttributeError):
            pass

    return _fallback_budget(income, savings_target), False


# --------------------------------------------------------------------------
# Fallback (non-AI) implementations — used automatically when no API key is
# configured or the AI request fails for any reason.
# --------------------------------------------------------------------------

def _fallback_spending_analysis(summary):
    expenses_by_category = summary.get("expenses_by_category", {}) or {}
    income = summary.get("income", 0) or 0
    expenses = summary.get("expenses", 0) or 0

    if not expenses_by_category:
        top_line = "No expenses have been recorded for this period yet."
    else:
        top_category = max(expenses_by_category, key=expenses_by_category.get)
        top_amount = expenses_by_category[top_category]
        top_line = f"Your largest expense category is {top_category}, totalling {top_amount:,.2f}."

    if income > 0 and expenses > income:
        overspend_line = " You spent more than you earned this period — consider reviewing discretionary categories."
    elif income > 0:
        overspend_line = f" Overall, expenses were {(expenses / income) * 100:.0f}% of income."
    else:
        overspend_line = " Add your income to get a clearer picture of your spending ratio."

    return _fallback_notice() + " " + top_line + overspend_line


def _fallback_savings_recommendation(summary):
    income = summary.get("income", 0) or 0
    expenses = summary.get("expenses", 0) or 0
    savings = income - expenses

    if income <= 0:
        return _fallback_notice() + " Record your income to receive a personalized savings recommendation."
    rate = (savings / income) * 100
    if rate < 10:
        tip = "Try the 50/30/20 rule: aim to direct at least 20% of income toward savings by trimming non-essential spending."
    elif rate < 20:
        tip = "You're saving a reasonable share of your income — consider automating transfers to a savings goal right after payday."
    else:
        tip = "Great savings rate — consider directing part of the surplus into an emergency fund or a longer-term goal."

    return f"{_fallback_notice()} Your current savings rate is about {rate:.0f}%. {tip}"


def _fallback_financial_summary(summary):
    income = summary.get("income", 0) or 0
    expenses = summary.get("expenses", 0) or 0
    savings = income - expenses
    over_budget_count = summary.get("over_budget_count", 0) or 0

    lines = [_fallback_notice()]
    lines.append(f"Total income was {income:,.2f} and total expenses were {expenses:,.2f}, leaving {savings:,.2f} in savings.")
    if over_budget_count:
        lines.append(f"{over_budget_count} budget categor{'y is' if over_budget_count == 1 else 'ies are'} currently over the set limit.")
    else:
        lines.append("All budget categories are currently within their set limits.")
    if income > 0 and savings / income >= 0.2:
        lines.append("This is a healthy savings rate — keep it up.")
    elif income > 0:
        lines.append("Consider looking for opportunities to increase your savings rate over time.")
    return " ".join(lines)


def _fallback_budget(income, savings_target):
    """A simple rule-of-thumb budget split when AI is unavailable."""
    income = float(income or 0)
    savings_target = float(savings_target or 0)
    remaining = max(income - savings_target, 0)

    weights = {
        "Housing": 0.30,
        "Food": 0.15,
        "Transport": 0.10,
        "Utilities": 0.08,
        "Shopping": 0.08,
        "Entertainment": 0.07,
        "Healthcare": 0.07,
        "Other": 0.15,
    }
    budget = {cat: round(remaining * weight, 2) for cat, weight in weights.items()}
    budget["Savings"] = round(savings_target, 2)
    return budget
