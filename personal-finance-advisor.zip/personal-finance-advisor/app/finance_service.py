"""
Pure financial calculation helpers.

Kept separate from routes so that calculations are easy to unit test
and reused consistently across the dashboard, reports, and AI advisor.
"""
from calendar import monthrange
from datetime import date

from sqlalchemy import extract, func

from app import db
from app.models import Income, Expense, ExpenseCategory, Budget, SavingsGoal


DEFAULT_EXPENSE_CATEGORIES = [
    "Food", "Rent", "Transport", "Utilities", "Shopping",
    "Entertainment", "Healthcare", "Education", "Bills", "Other",
]

DEFAULT_INCOME_CATEGORIES = ["Salary", "Freelancing", "Business", "Investment", "Other"]


def ensure_default_categories(user_id):
    """Create the default expense categories for a user if they don't exist yet."""
    existing = {c.name for c in ExpenseCategory.query.filter_by(user_id=user_id).all()}
    created = False
    for name in DEFAULT_EXPENSE_CATEGORIES:
        if name not in existing:
            db.session.add(ExpenseCategory(user_id=user_id, name=name))
            created = True
    if created:
        db.session.commit()


def get_total_income(user_id, month=None, year=None):
    query = db.session.query(func.coalesce(func.sum(Income.amount), 0.0)).filter(Income.user_id == user_id)
    if month and year:
        query = query.filter(extract("month", Income.date) == month, extract("year", Income.date) == year)
    return float(query.scalar() or 0.0)


def get_total_expenses(user_id, month=None, year=None):
    query = db.session.query(func.coalesce(func.sum(Expense.amount), 0.0)).filter(Expense.user_id == user_id)
    if month and year:
        query = query.filter(extract("month", Expense.date) == month, extract("year", Expense.date) == year)
    return float(query.scalar() or 0.0)


def get_expenses_by_category(user_id, month=None, year=None):
    query = (
        db.session.query(ExpenseCategory.name, func.coalesce(func.sum(Expense.amount), 0.0))
        .join(Expense, Expense.category_id == ExpenseCategory.id)
        .filter(Expense.user_id == user_id)
    )
    if month and year:
        query = query.filter(extract("month", Expense.date) == month, extract("year", Expense.date) == year)
    query = query.group_by(ExpenseCategory.name)
    return {name: float(total) for name, total in query.all()}


def get_monthly_totals(user_id, months_back=6):
    """Return income/expense totals for the last N months (oldest to newest)."""
    today = date.today()
    results = []
    y, m = today.year, today.month
    period = []
    for _ in range(months_back):
        period.append((y, m))
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    period.reverse()

    for (yy, mm) in period:
        income = get_total_income(user_id, mm, yy)
        expenses = get_total_expenses(user_id, mm, yy)
        label = date(yy, mm, 1).strftime("%b %Y")
        results.append({"label": label, "month": mm, "year": yy, "income": income, "expenses": expenses})
    return results


def get_budget_status(user_id, month, year):
    """Compare each budgeted category with actual spending for the period."""
    budgets = Budget.query.filter_by(user_id=user_id, month=month, year=year).all()
    spent_by_category = get_expenses_by_category(user_id, month, year)

    status = []
    for b in budgets:
        spent = spent_by_category.get(b.category, 0.0)
        remaining = b.amount - spent
        pct_used = round((spent / b.amount) * 100, 1) if b.amount > 0 else 0
        status.append({
            "id": b.id,
            "category": b.category,
            "budget": b.amount,
            "spent": spent,
            "remaining": remaining,
            "percent_used": pct_used,
            "over_budget": spent > b.amount,
        })
    return status


def calculate_savings(income, expenses):
    return income - expenses


def calculate_savings_rate(income, expenses):
    if not income or income <= 0:
        return 0.0
    savings = calculate_savings(income, expenses)
    return round((savings / income) * 100, 1)


def calculate_expense_ratio(income, expenses):
    if not income or income <= 0:
        return 0.0
    return round((expenses / income) * 100, 1)


def get_financial_health(user_id, month, year):
    income = get_total_income(user_id, month, year)
    expenses = get_total_expenses(user_id, month, year)
    savings = calculate_savings(income, expenses)
    savings_rate = calculate_savings_rate(income, expenses)
    expense_ratio = calculate_expense_ratio(income, expenses)

    budget_status = get_budget_status(user_id, month, year)
    total_budget = sum(b["budget"] for b in budget_status)
    total_spent_against_budget = sum(b["spent"] for b in budget_status)
    budget_utilization = round((total_spent_against_budget / total_budget) * 100, 1) if total_budget > 0 else 0
    over_budget_count = sum(1 for b in budget_status if b["over_budget"])

    goals = SavingsGoal.query.filter_by(user_id=user_id).all()
    if goals:
        avg_goal_progress = round(sum(g.progress_percent for g in goals) / len(goals), 1)
    else:
        avg_goal_progress = 0.0

    return {
        "income": income,
        "expenses": expenses,
        "savings": savings,
        "savings_rate": savings_rate,
        "expense_ratio": expense_ratio,
        "budget_utilization": budget_utilization,
        "over_budget_count": over_budget_count,
        "goal_progress": avg_goal_progress,
    }


def get_top_spending_categories(user_id, month, year, limit=5):
    by_category = get_expenses_by_category(user_id, month, year)
    sorted_items = sorted(by_category.items(), key=lambda x: x[1], reverse=True)
    return sorted_items[:limit]


def days_in_month(month, year):
    return monthrange(year, month)[1]
