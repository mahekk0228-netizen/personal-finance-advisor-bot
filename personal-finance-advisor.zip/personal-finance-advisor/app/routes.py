from datetime import date, datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user

from app import db
from app.models import Income, Expense, ExpenseCategory, Budget, SavingsGoal, MonthlyReport
from app import finance_service as fs
from app import ai_service

main_bp = Blueprint("main", __name__)


def _parse_float(value, field_name, errors, allow_zero=True):
    try:
        f = float(value)
    except (TypeError, ValueError):
        errors.append(f"{field_name} must be a valid number.")
        return None
    if f < 0 or (not allow_zero and f == 0):
        errors.append(f"{field_name} must be a positive number.")
        return None
    return f


def _parse_date(value, field_name, errors, required=True):
    if not value:
        if required:
            errors.append(f"{field_name} is required.")
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        errors.append(f"{field_name} must be a valid date (YYYY-MM-DD).")
        return None


@main_bp.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return render_template("index.html")


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------

@main_bp.route("/dashboard")
@login_required
def dashboard():
    today = date.today()
    month, year = today.month, today.year

    total_income = fs.get_total_income(current_user.id, month, year)
    total_expenses = fs.get_total_expenses(current_user.id, month, year)
    savings = fs.calculate_savings(total_income, total_expenses)
    savings_rate = fs.calculate_savings_rate(total_income, total_expenses)

    budget_status = fs.get_budget_status(current_user.id, month, year)
    total_budget = sum(b["budget"] for b in budget_status)
    total_spent = sum(b["spent"] for b in budget_status)
    remaining_budget = total_budget - total_spent

    expenses_by_category = fs.get_expenses_by_category(current_user.id, month, year)
    monthly_totals = fs.get_monthly_totals(current_user.id, months_back=6)
    goals = SavingsGoal.query.filter_by(user_id=current_user.id).order_by(SavingsGoal.created_at.desc()).all()

    return render_template(
        "dashboard.html",
        total_income=total_income,
        total_expenses=total_expenses,
        savings=savings,
        savings_rate=savings_rate,
        total_budget=total_budget,
        total_spent=total_spent,
        remaining_budget=remaining_budget,
        budget_status=budget_status,
        expenses_by_category=expenses_by_category,
        monthly_totals=monthly_totals,
        goals=goals,
        current_month_label=today.strftime("%B %Y"),
    )


# --------------------------------------------------------------------------
# Profile
# --------------------------------------------------------------------------

@main_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        errors = []
        name = (request.form.get("name") or "").strip()
        monthly_income = _parse_float(request.form.get("monthly_income", "0"), "Monthly income", errors)
        monthly_savings_target = _parse_float(request.form.get("monthly_savings_target", "0"), "Savings target", errors)
        financial_goal = (request.form.get("financial_goal") or "").strip()
        currency_symbol = (request.form.get("currency_symbol") or "\u20b9").strip()[:5]

        if not name:
            errors.append("Full name is required.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return redirect(url_for("main.profile"))

        current_user.name = name
        current_user.monthly_income = monthly_income
        current_user.monthly_savings_target = monthly_savings_target
        current_user.financial_goal = financial_goal
        current_user.currency_symbol = currency_symbol
        db.session.commit()
        flash("Profile updated successfully.", "success")
        return redirect(url_for("main.profile"))

    return render_template("profile.html")


# --------------------------------------------------------------------------
# Income
# --------------------------------------------------------------------------

@main_bp.route("/income", methods=["GET", "POST"])
@login_required
def income():
    if request.method == "POST":
        errors = []
        source = (request.form.get("source") or "").strip()
        category = (request.form.get("category") or "Other").strip()
        amount = _parse_float(request.form.get("amount"), "Amount", errors, allow_zero=False)
        income_date = _parse_date(request.form.get("date"), "Date", errors)
        description = (request.form.get("description") or "").strip()

        if not source:
            errors.append("Income source is required.")

        if errors:
            for err in errors:
                flash(err, "danger")
        else:
            record = Income(
                user_id=current_user.id, source=source, category=category,
                amount=amount, date=income_date, description=description,
            )
            db.session.add(record)
            db.session.commit()
            flash("Income added successfully.", "success")
        return redirect(url_for("main.income"))

    records = Income.query.filter_by(user_id=current_user.id).order_by(Income.date.desc()).all()
    total = sum(r.amount for r in records)
    return render_template("income.html", records=records, total=total, today=date.today().isoformat())


@main_bp.route("/income/<int:income_id>/edit", methods=["POST"])
@login_required
def edit_income(income_id):
    record = Income.query.filter_by(id=income_id, user_id=current_user.id).first()
    if record is None:
        abort(404)

    errors = []
    source = (request.form.get("source") or "").strip()
    category = (request.form.get("category") or "Other").strip()
    amount = _parse_float(request.form.get("amount"), "Amount", errors, allow_zero=False)
    income_date = _parse_date(request.form.get("date"), "Date", errors)
    description = (request.form.get("description") or "").strip()

    if not source:
        errors.append("Income source is required.")

    if errors:
        for err in errors:
            flash(err, "danger")
    else:
        record.source = source
        record.category = category
        record.amount = amount
        record.date = income_date
        record.description = description
        db.session.commit()
        flash("Income updated.", "success")
    return redirect(url_for("main.income"))


@main_bp.route("/income/<int:income_id>/delete", methods=["POST"])
@login_required
def delete_income(income_id):
    record = Income.query.filter_by(id=income_id, user_id=current_user.id).first()
    if record is None:
        abort(404)
    db.session.delete(record)
    db.session.commit()
    flash("Income deleted.", "info")
    return redirect(url_for("main.income"))


# --------------------------------------------------------------------------
# Expenses
# --------------------------------------------------------------------------

@main_bp.route("/expenses", methods=["GET", "POST"])
@login_required
def expenses():
    fs.ensure_default_categories(current_user.id)

    if request.method == "POST":
        errors = []
        category_id = request.form.get("category_id")
        new_category_name = (request.form.get("new_category_name") or "").strip()
        amount = _parse_float(request.form.get("amount"), "Amount", errors, allow_zero=False)
        expense_date = _parse_date(request.form.get("date"), "Date", errors)
        description = (request.form.get("description") or "").strip()

        category = None
        if new_category_name:
            category = ExpenseCategory.query.filter_by(user_id=current_user.id, name=new_category_name).first()
            if category is None:
                category = ExpenseCategory(user_id=current_user.id, name=new_category_name)
                db.session.add(category)
                db.session.flush()
        elif category_id:
            category = ExpenseCategory.query.filter_by(id=category_id, user_id=current_user.id).first()

        if category is None:
            errors.append("Please choose or create a valid category.")

        if errors:
            for err in errors:
                flash(err, "danger")
            db.session.rollback()
        else:
            record = Expense(
                user_id=current_user.id, category_id=category.id,
                amount=amount, date=expense_date, description=description,
            )
            db.session.add(record)
            db.session.commit()
            flash("Expense added successfully.", "success")
        return redirect(url_for("main.expenses"))

    records = Expense.query.filter_by(user_id=current_user.id).order_by(Expense.date.desc()).all()
    categories = ExpenseCategory.query.filter_by(user_id=current_user.id).order_by(ExpenseCategory.name).all()
    total = sum(r.amount for r in records)
    return render_template(
        "expenses.html", records=records, categories=categories, total=total, today=date.today().isoformat(),
    )


@main_bp.route("/expenses/<int:expense_id>/edit", methods=["POST"])
@login_required
def edit_expense(expense_id):
    record = Expense.query.filter_by(id=expense_id, user_id=current_user.id).first()
    if record is None:
        abort(404)

    errors = []
    category_id = request.form.get("category_id")
    amount = _parse_float(request.form.get("amount"), "Amount", errors, allow_zero=False)
    expense_date = _parse_date(request.form.get("date"), "Date", errors)
    description = (request.form.get("description") or "").strip()

    category = ExpenseCategory.query.filter_by(id=category_id, user_id=current_user.id).first()
    if category is None:
        errors.append("Please choose a valid category.")

    if errors:
        for err in errors:
            flash(err, "danger")
    else:
        record.category_id = category.id
        record.amount = amount
        record.date = expense_date
        record.description = description
        db.session.commit()
        flash("Expense updated.", "success")
    return redirect(url_for("main.expenses"))


@main_bp.route("/expenses/<int:expense_id>/delete", methods=["POST"])
@login_required
def delete_expense(expense_id):
    record = Expense.query.filter_by(id=expense_id, user_id=current_user.id).first()
    if record is None:
        abort(404)
    db.session.delete(record)
    db.session.commit()
    flash("Expense deleted.", "info")
    return redirect(url_for("main.expenses"))


# --------------------------------------------------------------------------
# Budget
# --------------------------------------------------------------------------

@main_bp.route("/budget", methods=["GET", "POST"])
@login_required
def budget():
    today = date.today()
    month = request.args.get("month", type=int) or today.month
    year = request.args.get("year", type=int) or today.year

    if request.method == "POST":
        errors = []
        category = (request.form.get("category") or "").strip()
        amount = _parse_float(request.form.get("amount"), "Budget amount", errors, allow_zero=False)
        b_month = request.form.get("month", type=int) or today.month
        b_year = request.form.get("year", type=int) or today.year

        if not category:
            errors.append("Category is required.")

        existing = Budget.query.filter_by(user_id=current_user.id, category=category, month=b_month, year=b_year).first()

        if errors:
            for err in errors:
                flash(err, "danger")
        else:
            if existing:
                existing.amount = amount
                flash("Budget updated for this category.", "success")
            else:
                db.session.add(Budget(user_id=current_user.id, category=category, amount=amount, month=b_month, year=b_year))
                flash("Budget created.", "success")
            db.session.commit()
        return redirect(url_for("main.budget", month=b_month, year=b_year))

    status = fs.get_budget_status(current_user.id, month, year)
    categories = fs.DEFAULT_EXPENSE_CATEGORIES
    return render_template(
        "budget.html", status=status, categories=categories, month=month, year=year, today=today,
    )


@main_bp.route("/budget/<int:budget_id>/delete", methods=["POST"])
@login_required
def delete_budget(budget_id):
    record = Budget.query.filter_by(id=budget_id, user_id=current_user.id).first()
    if record is None:
        abort(404)
    month, year = record.month, record.year
    db.session.delete(record)
    db.session.commit()
    flash("Budget deleted.", "info")
    return redirect(url_for("main.budget", month=month, year=year))


# --------------------------------------------------------------------------
# Savings Goals
# --------------------------------------------------------------------------

@main_bp.route("/savings", methods=["GET", "POST"])
@login_required
def savings():
    if request.method == "POST":
        errors = []
        name = (request.form.get("name") or "").strip()
        target_amount = _parse_float(request.form.get("target_amount"), "Target amount", errors, allow_zero=False)
        current_amount = _parse_float(request.form.get("current_amount", "0"), "Current saved amount", errors)
        deadline = _parse_date(request.form.get("deadline"), "Deadline", errors, required=False)
        description = (request.form.get("description") or "").strip()

        if not name:
            errors.append("Goal name is required.")

        if errors:
            for err in errors:
                flash(err, "danger")
        else:
            goal = SavingsGoal(
                user_id=current_user.id, name=name, target_amount=target_amount,
                current_amount=current_amount or 0, deadline=deadline, description=description,
            )
            db.session.add(goal)
            db.session.commit()
            flash("Savings goal created.", "success")
        return redirect(url_for("main.savings"))

    goals = SavingsGoal.query.filter_by(user_id=current_user.id).order_by(SavingsGoal.created_at.desc()).all()
    return render_template("savings.html", goals=goals)


@main_bp.route("/savings/<int:goal_id>/add", methods=["POST"])
@login_required
def add_to_savings(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first()
    if goal is None:
        abort(404)

    errors = []
    amount = _parse_float(request.form.get("amount"), "Amount", errors, allow_zero=False)
    if errors:
        for err in errors:
            flash(err, "danger")
    else:
        goal.current_amount = (goal.current_amount or 0) + amount
        db.session.commit()
        flash(f"Added to '{goal.name}'.", "success")
    return redirect(url_for("main.savings"))


@main_bp.route("/savings/<int:goal_id>/delete", methods=["POST"])
@login_required
def delete_savings_goal(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first()
    if goal is None:
        abort(404)
    db.session.delete(goal)
    db.session.commit()
    flash("Savings goal deleted.", "info")
    return redirect(url_for("main.savings"))


# --------------------------------------------------------------------------
# AI Advisor
# --------------------------------------------------------------------------

def _build_financial_summary(month, year):
    income = fs.get_total_income(current_user.id, month, year)
    expenses = fs.get_total_expenses(current_user.id, month, year)
    expenses_by_category = fs.get_expenses_by_category(current_user.id, month, year)
    budget_status = fs.get_budget_status(current_user.id, month, year)
    over_budget_count = sum(1 for b in budget_status if b["over_budget"])

    return {
        "income": income,
        "expenses": expenses,
        "savings": fs.calculate_savings(income, expenses),
        "savings_rate": fs.calculate_savings_rate(income, expenses),
        "expenses_by_category": expenses_by_category,
        "over_budget_count": over_budget_count,
        "financial_goal": current_user.financial_goal,
        "savings_target": current_user.monthly_savings_target,
    }


@main_bp.route("/advisor")
@login_required
def advisor():
    today = date.today()
    summary = _build_financial_summary(today.month, today.year)

    spending_analysis, spending_is_ai = ai_service.analyze_spending(summary)
    savings_recommendation, savings_is_ai = ai_service.generate_savings_recommendation(summary)
    financial_summary, summary_is_ai = ai_service.generate_financial_summary(summary)

    ai_available = spending_is_ai or savings_is_ai or summary_is_ai

    return render_template(
        "advisor.html",
        summary=summary,
        spending_analysis=spending_analysis,
        savings_recommendation=savings_recommendation,
        financial_summary=financial_summary,
        ai_available=ai_available,
        disclaimer=ai_service.DISCLAIMER,
    )


@main_bp.route("/advisor/budget-generator", methods=["GET", "POST"])
@login_required
def budget_generator():
    generated_budget = None
    used_ai = False

    if request.method == "POST":
        errors = []
        income_val = _parse_float(request.form.get("income"), "Monthly income", errors, allow_zero=False)
        savings_target = _parse_float(request.form.get("savings_target", "0"), "Savings target", errors)
        financial_goal = (request.form.get("financial_goal") or "").strip()

        if errors:
            for err in errors:
                flash(err, "danger")
        else:
            today = date.today()
            existing_expenses = fs.get_expenses_by_category(current_user.id, today.month, today.year)
            generated_budget, used_ai = ai_service.generate_budget(
                income_val, savings_target, financial_goal, existing_expenses,
            )

    return render_template(
        "budget_generator.html",
        generated_budget=generated_budget,
        used_ai=used_ai,
        disclaimer=ai_service.DISCLAIMER,
    )


# --------------------------------------------------------------------------
# Reports
# --------------------------------------------------------------------------

@main_bp.route("/reports")
@login_required
def reports():
    today = date.today()
    month = request.args.get("month", type=int) or today.month
    year = request.args.get("year", type=int) or today.year

    income = fs.get_total_income(current_user.id, month, year)
    expenses = fs.get_total_expenses(current_user.id, month, year)
    savings = fs.calculate_savings(income, expenses)
    savings_rate = fs.calculate_savings_rate(income, expenses)
    top_categories = fs.get_top_spending_categories(current_user.id, month, year)
    budget_status = fs.get_budget_status(current_user.id, month, year)

    ai_recommendation = None
    ai_available = False
    if income or expenses:
        summary = _build_financial_summary(month, year)
        ai_recommendation, ai_available = ai_service.generate_financial_summary(summary)

    period_label = date(year, month, 1).strftime("%B %Y")

    return render_template(
        "reports.html",
        month=month, year=year, period_label=period_label,
        income=income, expenses=expenses, savings=savings, savings_rate=savings_rate,
        top_categories=top_categories, budget_status=budget_status,
        ai_recommendation=ai_recommendation, ai_available=ai_available,
        disclaimer=ai_service.DISCLAIMER,
    )
