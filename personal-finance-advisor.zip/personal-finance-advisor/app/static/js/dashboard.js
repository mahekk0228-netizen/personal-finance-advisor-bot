// Reads financial data embedded by the server (dashboard.html) and renders
// Chart.js visualizations. No values are hard-coded here.

document.addEventListener("DOMContentLoaded", function () {
    const dataEl = document.getElementById("dashboard-data");
    if (!dataEl) return;

    const categories = JSON.parse(dataEl.dataset.categories || "{}");
    const monthly = JSON.parse(dataEl.dataset.monthly || "[]");
    const budget = JSON.parse(dataEl.dataset.budget || "[]");

    const palette = [
        "#4e73df", "#1cc88a", "#36b9cc", "#f6c23e", "#e74a3b",
        "#858796", "#6f42c1", "#20c997", "#fd7e14", "#0dcaf0",
    ];

    // 1. Expense by category (doughnut)
    const categoryCtx = document.getElementById("categoryChart");
    if (categoryCtx) {
        const labels = Object.keys(categories);
        const values = Object.values(categories);
        new Chart(categoryCtx, {
            type: "doughnut",
            data: {
                labels: labels.length ? labels : ["No expenses yet"],
                datasets: [{
                    data: values.length ? values : [1],
                    backgroundColor: palette,
                }],
            },
            options: { responsive: true, plugins: { legend: { position: "bottom" } } },
        });
    }

    // 2. Income vs Expenses (bar) - last 6 months
    const trendCtx = document.getElementById("trendChart");
    if (trendCtx) {
        new Chart(trendCtx, {
            type: "bar",
            data: {
                labels: monthly.map((m) => m.label),
                datasets: [
                    { label: "Income", data: monthly.map((m) => m.income), backgroundColor: "#1cc88a" },
                    { label: "Expenses", data: monthly.map((m) => m.expenses), backgroundColor: "#e74a3b" },
                ],
            },
            options: { responsive: true, plugins: { legend: { position: "bottom" } } },
        });
    }

    // 3. Monthly spending trend (line)
    const lineCtx = document.getElementById("spendingLineChart");
    if (lineCtx) {
        new Chart(lineCtx, {
            type: "line",
            data: {
                labels: monthly.map((m) => m.label),
                datasets: [{
                    label: "Expenses",
                    data: monthly.map((m) => m.expenses),
                    borderColor: "#4e73df",
                    backgroundColor: "rgba(78,115,223,0.15)",
                    fill: true,
                    tension: 0.3,
                }],
            },
            options: { responsive: true, plugins: { legend: { display: false } } },
        });
    }

    // 4. Budget vs Actual (bar)
    const budgetCtx = document.getElementById("budgetChart");
    if (budgetCtx) {
        new Chart(budgetCtx, {
            type: "bar",
            data: {
                labels: budget.length ? budget.map((b) => b.category) : ["No budgets set"],
                datasets: [
                    { label: "Budget", data: budget.length ? budget.map((b) => b.budget) : [0], backgroundColor: "#36b9cc" },
                    { label: "Spent", data: budget.length ? budget.map((b) => b.spent) : [0], backgroundColor: "#f6c23e" },
                ],
            },
            options: { responsive: true, plugins: { legend: { position: "bottom" } } },
        });
    }
});
