"""
Creates a demo account with sample financial data for testing/demonstration.

Usage:
    python seed.py

This will NOT touch any existing user's data. It only creates (or reuses)
a dedicated demo account: demo@example.com / demo1234
"""
from datetime import date, timedelta

from app import create_app, db
from app.models import User, Income, ExpenseCategory, Expense, Budget, SavingsGoal
from app.finance_service import DEFAULT_EXPENSE_CATEGORIES

DEMO_EMAIL = "demo@example.com"
DEMO_PASSWORD = "demo1234"


def seed():
    app = create_app("development")
    with app.app_context():
        user = User.query.filter_by(email=DEMO_EMAIL).first()
        if user is None:
            user = User(name="Demo User", email=DEMO_EMAIL, monthly_income=60000, monthly_savings_target=12000,
                        financial_goal="Build a 6-month emergency fund", currency="INR", currency_symbol="\u20b9")
            user.set_password(DEMO_PASSWORD)
            db.session.add(user)
            db.session.commit()
            print(f"Created demo user: {DEMO_EMAIL} / {DEMO_PASSWORD}")
        else:
            print(f"Demo user already exists: {DEMO_EMAIL} / {DEMO_PASSWORD}")

        if Income.query.filter_by(user_id=user.id).first() is None:
            today = date.today()
            db.session.add(Income(user_id=user.id, source="Monthly Salary", category="Salary",
                                   amount=60000, date=today.replace(day=1), description="Primary job"))
            db.session.add(Income(user_id=user.id, source="Freelance Project", category="Freelancing",
                                   amount=8000, date=today.replace(day=15), description="Web design gig"))
            print("Added sample income records.")

        categories = {}
        for name in DEFAULT_EXPENSE_CATEGORIES:
            cat = ExpenseCategory.query.filter_by(user_id=user.id, name=name).first()
            if cat is None:
                cat = ExpenseCategory(user_id=user.id, name=name)
                db.session.add(cat)
                db.session.flush()
            categories[name] = cat
        db.session.commit()

        if Expense.query.filter_by(user_id=user.id).first() is None:
            today = date.today()
            sample_expenses = [
                ("Food", 6500, "Groceries and dining"),
                ("Rent", 15000, "Monthly rent"),
                ("Transport", 3200, "Fuel and cab rides"),
                ("Utilities", 2100, "Electricity and internet"),
                ("Shopping", 4200, "Clothes"),
                ("Entertainment", 1800, "Movies and subscriptions"),
                ("Healthcare", 1200, "Pharmacy"),
            ]
            for cat_name, amount, desc in sample_expenses:
                db.session.add(Expense(user_id=user.id, category_id=categories[cat_name].id,
                                        amount=amount, date=today - timedelta(days=5), description=desc))
            print("Added sample expense records.")

        if Budget.query.filter_by(user_id=user.id).first() is None:
            today = date.today()
            sample_budgets = [("Food", 6000), ("Rent", 15000), ("Transport", 3000),
                               ("Shopping", 3000), ("Entertainment", 2000)]
            for cat_name, amount in sample_budgets:
                db.session.add(Budget(user_id=user.id, category=cat_name, amount=amount,
                                       month=today.month, year=today.year))
            print("Added sample budgets.")

        if SavingsGoal.query.filter_by(user_id=user.id).first() is None:
            db.session.add(SavingsGoal(user_id=user.id, name="Emergency Fund", target_amount=50000,
                                        current_amount=25000, deadline=date.today() + timedelta(days=180),
                                        description="6 months of essential expenses"))
            print("Added sample savings goal.")

        db.session.commit()
        print("Seeding complete.")


if __name__ == "__main__":
    seed()
