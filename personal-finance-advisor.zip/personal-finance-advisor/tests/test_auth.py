from tests.conftest import register, login
from app.models import User


def test_register_creates_user(client, app):
    response = register(client)
    assert response.status_code == 200
    with app.app_context():
        assert User.query.filter_by(email="test@example.com").first() is not None


def test_register_duplicate_email_fails(client, app):
    register(client)
    response = register(client)
    assert b"already exists" in response.data


def test_password_is_hashed(client, app):
    register(client)
    with app.app_context():
        user = User.query.filter_by(email="test@example.com").first()
        assert user.password_hash != "password123"
        assert user.check_password("password123")


def test_login_success(client):
    register(client)
    response = login(client)
    assert response.status_code == 200
    assert b"Dashboard" in response.data or b"dashboard" in response.data.lower()


def test_login_invalid_password(client):
    register(client)
    response = login(client, password="wrongpassword")
    assert b"Invalid email or password" in response.data


def test_dashboard_requires_login(client):
    response = client.get("/dashboard", follow_redirects=True)
    assert b"log in" in response.data.lower() or b"login" in response.data.lower()


def test_logout(client):
    register(client)
    login(client)
    response = client.get("/logout", follow_redirects=True)
    assert response.status_code == 200

    # After logout, the dashboard should redirect back to the login page.
    dashboard_response = client.get("/dashboard", follow_redirects=False)
    assert dashboard_response.status_code == 302
    assert "/login" in dashboard_response.headers["Location"]
