from app import finance_service as fs


def test_calculate_savings():
    assert fs.calculate_savings(50000, 30000) == 20000
    assert fs.calculate_savings(10000, 15000) == -5000


def test_calculate_savings_rate():
    assert fs.calculate_savings_rate(50000, 30000) == 40.0


def test_calculate_savings_rate_zero_income_no_division_error():
    assert fs.calculate_savings_rate(0, 5000) == 0.0
    assert fs.calculate_savings_rate(None, 5000) == 0.0


def test_calculate_expense_ratio():
    assert fs.calculate_expense_ratio(50000, 25000) == 50.0


def test_calculate_expense_ratio_zero_income():
    assert fs.calculate_expense_ratio(0, 1000) == 0.0


def test_savings_goal_progress_percent(app):
    from app.models import SavingsGoal
    goal = SavingsGoal(target_amount=1000, current_amount=250)
    assert goal.progress_percent == 25.0


def test_savings_goal_progress_caps_at_100(app):
    from app.models import SavingsGoal
    goal = SavingsGoal(target_amount=1000, current_amount=5000)
    assert goal.progress_percent == 100


def test_savings_goal_progress_zero_target(app):
    from app.models import SavingsGoal
    goal = SavingsGoal(target_amount=0, current_amount=0)
    assert goal.progress_percent == 0
