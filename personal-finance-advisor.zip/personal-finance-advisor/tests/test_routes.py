from datetime import date

from tests.conftest import register, login


def _auth_client(client):
    register(client)
    login(client)
    return client


def test_add_income(client):
    _auth_client(client)
    response = client.post(
        "/income",
        data={"source": "Salary", "category": "Salary", "amount": "5000",
              "date": date.today().isoformat(), "description": "Monthly pay"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Income added successfully" in response.data


def test_add_income_rejects_negative_amount(client):
    _auth_client(client)
    response = client.post(
        "/income",
        data={"source": "Salary", "category": "Salary", "amount": "-100",
              "date": date.today().isoformat(), "description": ""},
        follow_redirects=True,
    )
    assert b"must be a positive number" in response.data


def test_add_expense_creates_category_and_expense(client):
    _auth_client(client)
    response = client.post(
        "/expenses",
        data={"category_id": "", "new_category_name": "Groceries", "amount": "250.50",
              "date": date.today().isoformat(), "description": "Weekly shop"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Expense added successfully" in response.data


def test_create_budget(client):
    _auth_client(client)
    today = date.today()
    response = client.post(
        "/budget",
        data={"category": "Food", "amount": "6000", "month": str(today.month), "year": str(today.year)},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Budget created" in response.data


def test_create_savings_goal(client):
    _auth_client(client)
    response = client.post(
        "/savings",
        data={"name": "Emergency Fund", "target_amount": "50000", "current_amount": "10000",
              "deadline": "", "description": "Rainy day fund"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Savings goal created" in response.data


def test_dashboard_loads_after_login(client):
    _auth_client(client)
    response = client.get("/dashboard")
    assert response.status_code == 200


def test_advisor_page_works_without_ai_key(client):
    """Advisor page must still render (with fallback text) if no AI key is configured."""
    _auth_client(client)
    response = client.get("/advisor")
    assert response.status_code == 200
    assert b"currently unavailable" in response.data


def test_404_page(client):
    response = client.get("/this-route-does-not-exist")
    assert response.status_code == 404
